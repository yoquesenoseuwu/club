/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondeeventos;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DatabaseConnection {
    // Detalles de la conexión
    private static final String URL = "jdbc:mysql://bbbx7cdcbcl53xxmjyxb-mysql.services.clever-cloud.com:21748/bbbx7cdcbcl53xxmjyxb";
    private static final String USER = "uwwqerjcglxxweor"; 
    private static final String PASSWORD = "vWobxeLnCiH11WTJg6N"; 

    // Método para establecer la conexión
    public static Connection getConnection() throws SQLException {
        Connection connection = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            System.out.println("Conexión establecida con éxito.");
        } catch (ClassNotFoundException e) {
            System.out.println("Error al cargar el controlador JDBC: " + e.getMessage());
        } 
        return connection;
    }
    
    
public static void agregarEstadio(String nombre, String direccion, int cantidadSectores) throws SQLException {
        String sql = "INSERT INTO Estadio (Nombre, Direccion) VALUES (?, ?, ?)";
        try (Connection connection = getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {

            statement.setString(1, nombre);
            statement.setString(2, direccion);
            statement.setInt(3, cantidadSectores);

            int rowsInserted = statement.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("Estadio cargado exitosamente.");
            } else {
                throw new SQLException("No se pudo cargar el estadio.");
            }
        } catch (SQLException e) {
            System.out.println("Error al cargar el estadio: " + e.getMessage());
            throw e;
        }
    }
    
    public static boolean estadioExiste(String nombre) {
        String sql = "SELECT * FROM Estadio WHERE nombre = ?";
        try (Connection connection = getConnection();
             PreparedStatement pstmt = connection.prepareStatement(sql)) {
            pstmt.setString(1, nombre);
            try (ResultSet rs = pstmt.executeQuery()) {
                return rs.next();  // Retorna true si encuentra un registro
            }
        } catch (SQLException e) {
            System.out.println("Error al verificar el usuario: " + e.getMessage());
        }
        return false;
    }

    
   // Método para probar la conexión a la base de datos
    public static void testConnection() {
        try (Connection conn = getConnection()) {
            if (conn != null && !conn.isClosed()) {
                System.out.println("La conexión está activa.");
            } else {
                System.out.println("No se pudo establecer la conexión.");
            }
        } catch (SQLException e) {
            System.out.println("Error al probar la conexión: " + e.getMessage());
        }
    }
}