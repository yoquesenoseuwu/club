/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondeeventos;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class EstadioDAO {

    public void agregarEstadio(String nombre, String direccion) throws SQLException {
        Connection con = DatabaseConnection.getConnection();
        String sql = "INSERT INTO estadio (nombre, direccion) VALUES (?, ?)";
        
        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, direccion);
            ps.executeUpdate();
            System.out.println("Estadio agregado correctamente.");
        } catch (SQLException e) {
            System.out.println("Error al agregar estadio.");
        }
    }
}