/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package gestiondeeventos;
import interfaz.PanelPrincipal;
/**
 *
 * @author ddesktop
 */
public class GestionDeEventos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        PanelPrincipal pantalla = new PanelPrincipal();
        pantalla.setSize(1042,576);
        pantalla.setLocation(0,0);
        pantalla.setVisible(true);

        
    }
    
}
